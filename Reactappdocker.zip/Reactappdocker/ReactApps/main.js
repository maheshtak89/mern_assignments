// 1. import REact OM
import React from 'react';
//2. Import ReactDOM for rendering React compoennt in DOM
import ReactDOM from 'react-dom'

import "!style!css!bootstrap/dist/css/bootstrap.min.css";
//import SimpleComponent from "./components/simpleComponent.jsx"
//import ProductComponent from "./components/application/productComponent.jsx"

import  ProductUIComponent  from "./components/application/productUIComponent.jsx";
// to render whatever in DOM
// ReactDOM.render(<SimpleComponent myname="Mahesh"/>, document.getElementById("app"));
// ReactDOM.render(<ProductComponent />, document.getElementById("app"));
ReactDOM.render(<ProductUIComponent />, document.getElementById("app"));