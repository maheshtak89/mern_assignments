import React, { Component } from 'react'

class SimpleComponent extends Component {
    // ctor will be used for state definition and to accept data from parent component
    constructor(props) {
        // the props represent data to received from the Paretn component
        super(props);       //super.. called to parent class
        //state declaration
        // this.state = {  }
        // event-binding to component
    }// end of ctor

    // render() method encapsulate DOM and its data with behaviour
    render() { 
        // this returns the DOM object aka Virtual DOM
        return ( 
            <div>
                <h2> The Simple Component {this.props.myname}</h2>
                <hr/>
                {/* Rendering another class as TAG here... */}
                <NewComponent />            
            </div>
         );// end of returnd
    }// end of render()
}// end of class
 
class NewComponent extends Component{    
    render() {
        return (
            <div>
                <h2> The New Component</h2>
            </div>
        )
    }
}

//this will used by some buddy....to export it written below line
export default SimpleComponent;