
import React, { Component } from 'react'
import  ProductService  from "./../../services/service.js";
import { func } from 'prop-types';

class ProductUIComponent extends Component {
    constructor(props) {
        super(props);
        this.state = {  
            ProductId: 0,
            ProductName: "",
            Price:0,
            CategoryName:"",
            Manufacturer:"",
            Products:[
                /* {ProductId:101, ProductName:"Laptop", Price: 45000, CategoryName: "Electronics", Manufacturer:"Dell"},
                {ProductId:102, ProductName:"TV", Price: 98000, CategoryName: "Electrical", Manufacturer:"Samsung"},
                {ProductId:103, ProductName:"Pizza", Price: 1200, CategoryName: "Foods", Manufacturer:"Zomato"} */
                
            ],
            Categories:["Electronics","Electrical","Foods","Vehicle"],
            Manufacturers:["Samsung","Intex","EF Beverages","Philips", "Bajaj","Clai","IBM","Sprite","Nike"],
            CriteriaName: "",
            Criteria: ["ProductId","ProductName","Price","CategoryName","Manufacturer"]
        };
        this.serve = new ProductService;
    }

    // e is an event-payload raised on target element, we can read the Payload data using 'e'.

    onChangeProduct(e){
        this.setState({[e.target.name]: e.target.value})
    }
        //onchangeCriteria()
    onChangeCriteria(e){
        this.setState(
            {CriteriaName: e.target.value},
        // console.log({Criteria: e.target.value})
        )
    }
    onChangeSort(e){
        this.setState({[e.target.name]: e.target.value})
    }
    onChangeReverse(e){
        this.setState({[e.target.name]: e.target.value})
    }
    onClickSort(e){
        let temp = this.state.Products;
        let criteriaType = this.state.CriteriaName;

        temp.sort(function(a,b){
            if(typeof a[criteriaType]== "string"){
                return a[criteriaType].toLowerCase().localeCompare(b[criteriaType].toLowerCase());
            }else{
                return a[criteriaType]-b[criteriaType];
            }
        });
        this.setState({Products: temp})
    }
    onClickReverse(e){
        let temp = this.state.Products;
        let criteriaType = this.state.CriteriaName;

        temp.reverse();
        this.setState({Products: temp})
    }
    // onChangeProductId(e){
    //     this.setState(
    //         {ProductId:e.target.value},
    //     )
    // }
    // onChangeProductName(e){
    //     this.setState(
    //         {ProductName:e.target.value},
    //     )
    // }
    // onChangePrice(e){
    //     this.setState(
    //         {Price:e.target.value},
    //     )
    // }
    // onChangeCategoryName(e){
    //     this.setState(
    //         {CategoryName:e.target.value},
    //     )
    // }
    // onChangeManufacturer(e){
    //     this.setState(
    //         {Manufacturer:e.target.value},
    //     )
    // }

    // method will be executed immediatly after the render() completes its job
   
    //button event methods..
    onClickClear(e){
        this.setState({ProductId: 0});
        this.setState({ProductName:""});
        this.setState({Price:0});
        this.setState({CategoryName:""});
        this.setState({Manufacturer:""});
    }
    onCLickSave(e){
        alert(`Record saved Success ! \n
        ${this.state.ProductId}
        ${this.state.ProductName}
        ${this.state.Price}
        ${this.state.CategoryName}
        ${this.state.Manufacturer}
        `)

            let prd={
                ProductId: this.state.ProductId,
                ProductName: this.state.ProductName,
                Price: this.state.Price,
                CategoryName: this.state.CategoryName,
                Manufacturer: this.state.Manufacturer
            };

            console.log("ProductUIComponent " + prd);
            
            this.serve.postData(prd)
                        .then(res => res.json())
                        .then(
                            resp => {
                                console.log(`Resp data ${resp.data}`)
                            let tempArray = this.state.Products.slice();
                            tempArray.push(resp.data);
                            this.setState({Products: tempArray})
                            })
                        .catch(error => console.log(error.status));
    }

    onClickUpdate(e){
        alert(`Record Updated Success ! \n
        ${this.state.ProductId}
        ${this.state.ProductName}
        ${this.state.Price}
        ${this.state.CategoryName}
        ${this.state.Manufacturer}
        `)

        let id = this.state.ProductId;

        let prd={
            ProductId: this.state.ProductId,
            ProductName: this.state.ProductName,
            Price: this.state.Price,
            CategoryName: this.state.CategoryName,
            Manufacturer: this.state.Manufacturer
        };

        console.log("ProductUIComponent Updated " + JSON.stringify(prd));
        
        this.serve.putData(id, prd)
                    .then(res => res.json())
                    .then(
                        resp => {
                            console.log(`Resp data ${resp.data}`)
                        let tempArray = this.state.Products.slice();
                        tempArray.push(resp.data);
                        this.setState({Products: tempArray})
                        })
                    .catch(error => console.log(error.status));

    }

    onClickDelete(e){
        alert(`Record Deleted Success ! \n
        ${this.state.ProductId}
        ${this.state.ProductName}
        ${this.state.Price}
        ${this.state.CategoryName}
        ${this.state.Manufacturer}
        `)

        let id = this.state.ProductId;
        
        this.serve.deleteData(id)
                    .then(res => res.json())
                    .then(
                        resp => {
                            console.log(`Resp data ${resp.data}`)
                        let tempArray = this.state.Products.slice();
                        tempArray.push(resp.data);
                        this.setState({Products: tempArray})
                        })
                    .catch(error => console.log(error.status));


    }


    getSelectedProduct(d){
        this.setState({ProductId: d.ProductId});
        this.setState({ProductName:d.ProductName});
        this.setState({Price:d.Price});
        this.setState({CategoryName:d.CategoryName});
        this.setState({Manufacturer:d.Manufacturer });
    }

    componentDidMount(){
        let tempArray = this.state.Products;
        let prds = this.serve.getData()
                                .then((data)=>data.json())
                                .then(value=>{
                                    console.log(JSON.stringify(value.data));
                                    this.setState({Products: value.data}),{Products: tempArray};
                                })
                                .catch(error => {
                                    console.log(`Error occured ${error.status}}`);
                                });
    }


   


    render() { 
        return ( 
            <div className="container">
                <div className="form-group">
                    <label htmlFor="ProductID" >Product Id</label>
                    <input type="text" className="form-control"
                    value={this.state.ProductId}                                // this line wil bind the data from state to HTML
                    onChange = {this.onChangeProduct.bind(this)}              // here this line is for, to make fields dynamic, default these are read-only, now we are making them 'onChange'
                    name="ProductId"
                    />
                </div>
                <div className="form-group">
                    <label htmlFor="ProductName" >Product Name</label>
                    <input type="text" className="form-control"
                    value={this.state.ProductName}
                    onChange = {this.onChangeProduct.bind(this)}
                    name="ProductName"
                    />
                </div>
                <div className="form-group">
                    <label htmlFor="Price" >Price</label>
                    <input type="text" className="form-control"
                    value={this.state.Price}
                    onChange = {this.onChangeProduct.bind(this)}
                    name="Price"
                    />
                </div>
                <div className="form-group">
                    <label htmlFor="CategoryName" >Category Name</label>
                    <select className="form-control"
                    value={this.state.CategoryName}
                    onChange = {this.onChangeProduct.bind(this)}
                    name="CategoryName"
                    >
                    {
                        this.state.Categories.map((c,i)=>(
                            <Options  key={i} data={c}/>
                        ))
                    }
                    </select>
                </div>
                <div className="form-group">
                    <label htmlFor="Manufacturer" >Manufacturer</label>
                    <select className="form-control"
                    value={this.state.Manufacturer}
                    onChange = {this.onChangeProduct.bind(this)}
                    name="Manufacturer"
                    >
                     {
                        this.state.Manufacturers.map((m,i)=>(
                            <Options  key={i} data={m}/>
                        ))
                    }
                    </select>
                </div>
                <div className="form-group">
                    <table className="table table-bordered table-striped">
                        <tbody>
                            <tr>
                                <td>
                                    <input
                                    type="button"
                                    value="New"
                                    className="btn btn-info"
                                    onClick={this.onClickClear.bind(this)}
                                    />
                                </td>
                                <td>
                                    <input
                                    type="button"
                                    value="Save"
                                    className="btn btn-success"
                                    onClick={this.onCLickSave.bind(this)}
                                    />
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <input
                                    type="button"
                                    value="Update"
                                    className="btn btn-warning"
                                    onClick={this.onClickUpdate.bind(this)}
                                    />
                                </td>
                                <td>
                                    <input
                                    type="button"
                                    value="Delete"
                                    className="btn btn-danger"
                                    onClick={this.onClickDelete.bind(this)}

                                    />
                                </td>
                            </tr>
                            <tr>
                                <td colSpan="2">
                                <h3><label htmlFor="Criteria">Criteria</label></h3>
                                    <select className="form-control"
                                    value={this.state.CriteriaName}
                                    onChange = {this.onChangeCriteria.bind(this)}
                                    name="Criteria"
                                    >
                                    {
                                        this.state.Criteria.map((m,i)=>(
                                            <Options  key={i} data={m}/>
                                        ))
                                    }
                                    </select>
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <div className="radio-inline">
                                        <label className="label label-lg">
                                            <input type="radio" name="radiobtn" 
                                            value="SORT"
                                            onChange={this.onChangeSort.bind(this)}
                                            onClick={this.onClickSort.bind(this)}
                                            /> SORT
                                        </label>
                                    </div>
                                </td>
                                <td>
                                    <div className="radio-inline">
                                        <label>
                                            <input type="radio" name="radiobtn" 
                                            value="REVERSE"
                                            onChange={this.onChangeReverse.bind(this)}
                                            onClick = {this.onClickReverse.bind(this)}
                                            /> REVERSE
                                        </label>
                                    </div>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                <div className="container">
                <table className="table table-bordered table-striped">
                    <thead>
                        <tr>
                            <th>Product Id</th>
                            <th>Product Name</th>
                            <th>Price</th>
                            <th>CatgeoryName</th>
                            <th>Manufacturer</th>
                        </tr>
                    </thead>
                    <tbody>
                        {
                            this.state.Products.map( (prd, idx) => (
                                    <TableRow key={idx} row={prd} 
                                        selected = {this.getSelectedProduct.bind(this)}
                                    />            
                                    // from here we are passing Product details by iterating over Products array
                                    // row will send this product to TableRow component

                                )
                            )
                        }
                    </tbody>
                </table>
            </div>
            </div>
            
         );
    }
}

// seperate class / component for rendring Options 
class Options extends Component{
    render(){
        return (
            // the props.data is the data passed from Parent of this component.
            <option value={this.props.data}>{this.props.data}</option>
        )
    }
}



// this table is to generate table rows
class TableRow extends Component{

    constructor(props){
        super(props);
    }
    
    onRowClick(){
        // a new "selected()" mwthod is used to passed received data
        this.props.selected(this.props.row);                // from here we r binding, this row to selected which will be available to PArent component
    }
    render(){
        return (
            <tr onClick={this.onRowClick.bind(this)}>
                {/* // here row is passed from Parent component */}
                <td>{this.props.row.ProductId}</td>         
                <td>{this.props.row.ProductName}</td>
                <td>{this.props.row.Price}</td>
                <td>{this.props.row.CategoryName}</td>
                <td>{this.props.row.Manufacturer}</td>
            </tr>
        );
    }

}

class Creteria extends Component{
    constructor(props){
        super(props);
    }

    render(){
        return(
            <div className>

            </div>
        )
    }
}
 
export default ProductUIComponent;