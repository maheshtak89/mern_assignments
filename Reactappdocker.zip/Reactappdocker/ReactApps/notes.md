**React Notes**

1. The React ObjectModel for following
    1. The 'Component' class:
        1. The 'constructor' => use to define state and behavious for the component.
        2. The 'render()' method  => used to control HTML DOM with data and bahaviour.
    2. Manages hierarchies of 'Components' with their life cycle.
        1. Manages Parent-Child rendering and Data sharing relationship across components.
    3. The JSX => babel-preset-es2015 and babel-preset-react libs
        1. REact.createClass() and React.createElement() objects for rendring.
2. The React-DOM lib:
    1. Uses JSX for rendering.
        1. Use component ObjectModel from 'react' lib.
        2. Only one 'Export default' per JSX file.

**======================================================================================================**

- React for Professioonal Apps
    - Stateless compoennt
        : component that have only DOM encapsulation and no data, (i.e state and prop) in it.
    - Statefull component
        : Has their own data, defined using 'state' object (predefine object), inside ctor.
        : the 'setState()' method of component class to update the state of component.
            - **setState({stateProperty:value}, {callBackFunction to update state in async mode})**
            **Note:- Callback is mandatory in case of state changes for <select> element**
        : Has data received from Parent component, define using props parameter passed to ctor.
        : props are always across the component
    - Statefull 'Controlled Component'
        : event and data binding for each editable element is used.
    - Statfull 'UnControlled Component'
        : state is not defined using state object, but the editable element has implicit object declaration.
    - React.js Design Pattern React 16.x+
        - Higher-Order-Component (HoC)