// 1. Import React OM
import React from "react";
// 2. Import ReactDOM for rendering React Component in DOM
import ReactDom from "react-dom";
// 3. Importing Boosttrap (or any other CSS/style/UI Kits)
import "!style!css!bootstrap/dist/css/bootstrap.min.css";

import CompanyListComponent from "./components/hoc/companylist.jsx";
import StockListComponent from "./components/hoc/stocklist.jsx"
import HoC from "./components/hoc/hoccomponent.jsx";

let companyData = [{
    id: 101,
    name: "Microsoft"
}, {
    id: 102,
    name: "IBM"
}]
let stockData = [{
    id: 101,
    name: "BSE",
    status: true
}, {
    id: 102,
    name: "NSE",
    status: false
}]


//calling factory methods or HOC by passing specific COmpoennt and its data.
let CompanyDataComponent = HoC(CompanyListComponent, companyData);
let StockListDataComponent = HoC(StockListComponent, stockData);

ReactDom.render( <
    StockListDataComponent / > , document.getElementById("app")

);