**React Notes**

1. The React ObjectModel for following
    1. The 'Component' class:
        1. The 'constructor' => use to define state and behavious for the component.
        2. The 'render()' method  => used to control HTML DOM with data and bahaviour.
    2. Manages hierarchies of 'Components' with their life cycle.
        1. Manages Parent-Child rendering and Data sharing relationship across components.
    3. The JSX => babel-preset-es2015 and babel-preset-react libs
        1. REact.createClass() and React.createElement() objects for rendring.
2. The React-DOM lib:
    1. Uses JSX for rendering.
        1. Use component ObjectModel from 'react' lib.
        2. Only one 'Export default' per JSX file.

**======================================================================================================**

- React for Professioonal Apps
    - Stateless compoennt
        : component that have only DOM encapsulation and no data, (i.e state and prop) in it.
    - Statefull component
        : Has their own data, defined using 'state' object (predefine object), inside ctor.
        : the 'setState()' method of component class to update the state of component.
            - **setState({stateProperty:value}, {callBackFunction to update state in async mode})**
            **Note:- Callback is mandatory in case of state changes for <select> element**
        : Has data received from Parent component, define using props parameter passed to ctor.
        : props are always across the component
    - Statefull 'Controlled Component'
        : event and data binding for each editable element is used.
    - Statfull 'UnControlled Component'
        : state is not defined using state object, but the editable element has implicit object declaration.
    - React.js Design Pattern React 16.x+
        - Higher-Order-Component (HoC)

        **============================================================================**

React Lifecycle:

**LifeCycle Statges**
    - Initial Render
                                                                        **First Render**            (as per 15.x)
                                                                            - GetDefaultprops ->
                                                                            GetInitialState ->
                                                                            ComponentWillMount ->  (deprecated in 16.x)
                            componentDidCatch(errorString, erroInfo)->      render ->
                                  (as per 16.x)                             componentDidMount


            //////////////////////////////////////////////////////////////////////////////////////////
                    componentDidCatch(errroString, errorInfo){
                        this.setState({
                            error:string;
                        })
                        errorLoggingTools.log(errorInfo);
                    }
            render(){
                    if(this.state.error) return <ShowErrorMessage error =
                        {
                            ///         
                        }
            }
            
    - props change
                                                                        ** props change**
                                                                            - componentWillReceiveProps -> (deprecated )
                                                                            shouldComponentUpdate ->
                                                                            componentWillUpdate ->
                                                                            render ->
                                                                            componentDidUpdate 


    - stage change                                                      
                                                                        **StateChnage**
                                                                            - 
    - Component Unmount




**==============================================================================================================**
Steps for React-Redux Apps
install redux and react-redux packages
redux :- Action Object, Reduce Object and Store Object
            Create Store() object : accepts 'reducer' as input parameter : Create a store if its not present else update(?) the existing store. Its he reducer, that update store based on action dipatched from various react components.
            The "CombineReducer", the object that aggrigate all the reducer function inside it.
react-redux :- Connect object: to conenct react component with redux store --> Internally manage component subscriptions with                   store. Provider Object: this will load store for the current application context aka global application                         store.


==========================================================================================
**Steps for Implementing project...**
1. PaperWork
2. Design COmponents
3. Write action.js
4. write reducer
5. provider
6. create store
7. Dispatched
8. Write Component
9. Map StateToProps.
===========================================================================================

**React Higher Order Component**
** HOC ** onwards 16.x v

s- advance technique for reusing component logic.
- not part of react api. Its design pattern and pure  function.
-  this function accept component and data as input.

** code **

===========================================================================================
This is Factory Method:  where we r passingg compontn and data
============================================================================================
import React, Component from 'react';

export default function Hoc(HocComponent, data){
    return (
        class extends component{
            constructor(props){
                super(props);
                this.state = {
                    data: data
                };
            }

            render(){
                return (
                    <HocCOmponent data = {this.state.data} {...this.props} />
                );
            }
        }
    )
}
=============================================================================================