import { Directive, Input } from "@angular/core";

// #The directive withs elector for "propertyBinding"

@Directive({
    selector:'[ setColor]'
})
export class ColorDirective{
    //property for class, map the property to directive selector to accept input 
    @Input("setColor")
    setColor : string;
    
    
}  