import { Component, OnInit, Input } from "@angular/core";
import { Product, Products } from "./app.prod.model";

@Component({
        selector: 'product-data',
        templateUrl: './product.html'
})

export class ProductComponent1 implements OnInit{
    products = Products;
    _FilterProducts: Array<Product>;
    _CategoryName: string;

    @Input()
    set categoryName(cname: string){
        this._CategoryName = (cname && cname.trim()) || 'No Category Selected';
        console.log(this._CategoryName);
    }

    get categoryName(){
        return this._CategoryName;
    }

    constructor(){
        this._FilterProducts = new Array<Product>();
        console.log('Product');
    }

    get filterProducts(){
        this._FilterProducts = new Array<Product>();
        for(let e of Products){
            if(e.categoryName === this._CategoryName){
              this._FilterProducts.push(e);
            }
        }
        return this._FilterProducts;
    }

    ngOnInit(){

    }
}