import { RouterModule, Routes, ActivatedRoute, ROUTES } from "@angular/router";
import { ModuleWithProviders } from "@angular/core";


// import { ProductComponent } from "../productcomponent/app.product.component";
// import { CategoryComponent } from "../../MultiComponentCOmmunication/app.category.component";
// import { ItemList } from "./../../MultiCompCommunicationInputAndOutput/app.Itemlist.component";
// import { AppGuardService } from "../../services/app.test.guard.service";
// import { DashBoardErrorCOmponent } from "./app.error.component";

import { DashBoardComponent } from "./app.main.component";
import { RegisterComponent } from "./app.regiser.component";

const routes: Routes = [
    {path: 'dashboard', component: DashBoardComponent },
    {path: '', redirectTo: 'dashboard', pathMatch:"full"},
    {path: 'register', component: RegisterComponent}
];

//register the route table for Route of the current angular app
// when "routing" is provided to "imports" of NgModule, this will load RouterModule with Route Table.
export const routing: ModuleWithProviders = RouterModule.forRoot(routes); 
