import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'app-register-component',
    template: `
        <h2> Welcome to Registration page.. </h2>
    `
})
export class RegisterComponent implements OnInit {
    constructor() { }

    ngOnInit(): void { }
}
