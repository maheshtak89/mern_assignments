import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'app-main-component',
    template: `
        <div class="container">
            <table class="table table-bordered table-striped">
                <tr>
                    <td>
                        <a [routerLink]="['home']">home</a>
                    </td>
                    <td>
                        <a [routerLink]="['about']">about</a>
                    </td>
                    <td>
                        <a [routerLink]="['contact']">contact</a>
                    </td>
                </tr>
            </table>
        </div>
        <router-outlet></router-outlet>
    `
})
export class MainComponent implements OnInit {
    id: number;

    constructor() {
        this.id = 1000;
     }

    ngOnInit(): void { }
}
