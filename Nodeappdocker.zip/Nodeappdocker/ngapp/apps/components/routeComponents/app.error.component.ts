
import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'app-error-component',
    template: `
        <h2> This is Error Component </h2>
        <a [routerLink] ="['home']">
        <input type="button" value="Go Back" /></a>
    `
})
export class ErrorCOmponent implements OnInit {
    constructor() { }

    ngOnInit(): void { }
}
