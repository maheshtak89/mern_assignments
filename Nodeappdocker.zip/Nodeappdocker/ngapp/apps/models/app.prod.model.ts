export class Product{
    constructor(
        public ProdId: number,
        public ProdName: string,
        public CatId: number
    ){}
}

export const Products : Array<Product> = new Array<Product>();
Products.push( new Product(1001, " P1", 101));
Products.push( new Product(1002, " P2", 101));
Products.push( new Product(1003, " P3", 102));
Products.push( new Product(1004, " P4", 102));
Products.push( new Product(1005, " P5", 103));
Products.push( new Product(1006, " P6", 103));
Products.push( new Product(1007, " P7", 104));
Products.push( new Product(1008, " P8", 104));
Products.push( new Product(1009, " P9", 105));
Products.push( new Product(1010, " P10", 105));
Products.push( new Product(1011, " P5", 102));
Products.push( new Product(1012, " P5", 103));
