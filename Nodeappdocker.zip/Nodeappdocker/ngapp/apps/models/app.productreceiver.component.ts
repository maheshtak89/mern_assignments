import { Component, OnInit } from "@angular/core";
import { Product, Products } from "./app.prod.model";
import { CommunicationService } from "./app.communication.service";

@Component({
    selector: "app-productreceiver-component",
    template: `
    <div class="container">
    <h2><strong> Product List : {{CatId}}</strong></h2>
    <table class="table table-bordered table-striped">
        <thead>
            <tr> 
                <td>Product ID</td>
                <td> Product Name </td>
                <td> Category ID </td>
            </tr>
        </thead>
        <tbody>
            <tr *ngFor="let p of filterProducts" >
                <td>{{p.ProdId}} </td>
                <td>{{p.ProdName}} </td>
                <td>{{p.CatId}}</td>
            </tr>
        </tbody>
    </table>
</div>
    `
})

export class ProductReceiverComponent {
    prd: Product;
    prods =  Products;
    CatId : number;
    private _FilterProducts : Array<Product>;

    constructor( private serv: CommunicationService){
        this.prd = new Product(0, "",0);
        this.CatId = 0;
        this._FilterProducts = new Array<Product>();
    }

    //4. OnINti
    ngOnInit(): void {
        //Called after the constructor, initializing input properties, and the first call to ngOnChanges.
        //Add 'implements OnInit' to the class.
        this.serv.receivedFilter.subscribe((param:number)=>{
            this.CatId = param;
        })

    }

    get filterProducts(): Array<Product>{
        this._FilterProducts = new Array<Product>();
        if(this.CatId > 0 ){
            this.prods.forEach( p =>{
                if( p.CatId      === this.CatId){
                    this._FilterProducts.push(p);
                }
            });
        }else{
            this._FilterProducts = this.prods;
        }
        return this._FilterProducts;
    }
}