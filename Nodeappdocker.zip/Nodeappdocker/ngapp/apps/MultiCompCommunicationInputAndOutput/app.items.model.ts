export class Item{
    constructor(
        public id: number,
        public name: string
    ){ }
}

export const items: Array<Item> = new Array<Item>();
items.push(new Item(101, "TV"));
items.push(new Item(102, "Refrigerator"));
items.push(new Item(103, "AC"));
items.push(new Item(104, "Bajaj Pulsar"));
items.push(new Item(105, "Kawasaki"));

