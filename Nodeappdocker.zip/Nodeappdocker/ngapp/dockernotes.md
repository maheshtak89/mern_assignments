//build the container
docker build -t dockerngapps

// run the container once it is build
docker run -it -v:usr/src/apps -v/usr/src/apps/nodes_module _p 9393:939 --rm dockerngapps

